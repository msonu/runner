<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class=container>
	<div class="footer">
		<p>copyright&copy 2016 All Right are Reserved</p>
		<p> created by Sonu Malik</p>	
		</div>
	</nav>
</div>
</body>
</html>