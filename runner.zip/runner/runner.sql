-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2016 at 09:58 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `runner`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `username` text NOT NULL,
  `email` text NOT NULL,
  `mobile` int(11) NOT NULL,
  `subject` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`username`, `email`, `mobile`, `subject`) VALUES
('', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
`id` int(11) NOT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `product_price` decimal(10,1) DEFAULT NULL,
  `old_price` decimal(10,1) DEFAULT NULL,
  `new_price` decimal(10,1) DEFAULT NULL,
  `tags` varchar(200) DEFAULT NULL,
  `size` varchar(100) DEFAULT NULL,
  `colors` varchar(200) DEFAULT NULL,
  `category` varchar(200) DEFAULT NULL,
  `descriptiotn` varchar(1000) DEFAULT NULL,
  `sku` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_price`, `old_price`, `new_price`, `tags`, `size`, `colors`, `category`, `descriptiotn`, `sku`) VALUES
(1, 'nike1', '301.0', '452.0', '333.0', 'sports', 'large', 'red,black', 'mens', 'ullamco laboris nisi ut aliquip ', 'images/1.jpg'),
(2, 'nike2', '61.0', '191.0', '114.0', 'sports', 'medium', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', 'images/2.jpg'),
(3, 'nike3', '327.0', '134.0', '64.0', 'sports', 'small', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', 'images/3.jpg'),
(4, 'nike4', '74.0', '347.0', '382.0', 'sports', 'extra large', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', 'images/2.jpg'),
(5, 'nike5', '73.0', '75.0', '276.0', 'sports', 'large', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', 'images/5.jpg'),
(6, 'nike6', '240.0', '56.0', '50.0', 'sports', 'medium', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', 'images/6.jpg'),
(7, 'nike7', '68.0', '204.0', '48.0', 'sports', 'small', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', 'images/7.jpg'),
(8, 'nike8', '149.0', '241.0', '323.0', 'sports', 'extra large', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', 'images/8.jpg'),
(9, 'nike9', '70.0', '235.0', '390.0', 'sports', 'large', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', 'images/9.jpg'),
(10, 'nike10', '71.0', '335.0', '440.0', 'sports', 'medium', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do ', 'images/10.jpg'),
(11, 'nike11', '431.0', '102.0', '271.0', 'sports', 'small', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do .', 'images/11.jpg'),
(12, 'nike12', '455.0', '424.0', '204.0', 'sports', 'extra large', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do ', 'images/12.jpg'),
(13, 'nike13', '239.0', '484.0', '67.0', 'sports', 'large', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do', 'images/13.jpg'),
(14, 'nike14', '365.0', '287.0', '289.0', 'sports', 'medium', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do', 'images/ss1.jpg'),
(15, 'nike15', '84.0', '399.0', '308.0', 'sports', 'small', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do ', 'images/ss2.jpg'),
(16, 'nike16', '378.0', '451.0', '178.0', 'sports', 'extra large', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do ', 'images/ss3.jpg'),
(17, 'nike17', '449.0', '497.0', '348.0', 'sports', 'large', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do ', 'images/ss4.jpg'),
(18, 'nike18', '156.0', '145.0', '100.0', 'sports', 'medium', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do', 'images/ss6.jpg'),
(19, 'nike19', '220.0', '183.0', '332.0', 'sports', 'small', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do ', 'images/4.jpg'),
(20, 'nike20', '160.0', '343.0', '451.0', 'sports', 'extra large', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do', 'images/1.jpg'),
(21, 'nike21', '261.0', '372.0', '348.0', 'casual', 'large', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do', 'images/2.jpg'),
(22, 'nike22', '263.0', '157.0', '202.0', 'sports', 'medium', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed d', 'images/3.jpg'),
(23, 'nike23', '181.0', '104.0', '291.0', 'sports', 'small', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do ', 'images/ss1.jpg'),
(24, 'nike24', '457.0', '458.0', '139.0', 'sports', 'extra large', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do', 'images/ss2.jpg'),
(25, 'nike25', '102.0', '309.0', '470.0', 'casual', 'large', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do', 'images/4.jpg'),
(26, 'nike26', '135.0', '234.0', '300.0', 'sports', 'medium', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/5.jpg'),
(27, 'nike27', '294.0', '268.0', '307.0', 'sports', 'small', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/6.jpg'),
(28, 'nike28', '353.0', '142.0', '292.0', 'sports', 'extra large', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/7.jpg'),
(29, 'nike29', '283.0', '349.0', '152.0', 'sports', 'large', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/8.jpg'),
(30, 'nike30', '369.0', '422.0', '89.0', 'sports', 'medium', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/9.jpg'),
(31, 'nike31', '432.0', '182.0', '118.0', 'sports', 'small', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/10.jpg'),
(32, 'nike32', '374.0', '171.0', '229.0', 'sports', 'extra large', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/ss3.jpg'),
(33, 'nike33', '196.0', '462.0', '151.0', 'sports', 'large', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/ss4.jpg'),
(34, 'nike34', '455.0', '92.0', '148.0', 'sports', 'medium', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/ss5.jpg'),
(35, 'nike35', '214.0', '79.0', '462.0', 'sports', 'small', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/ss6.jpg'),
(36, 'nike36', '285.0', '480.0', '270.0', 'sports', 'extra large', 'silver,black,grey', 'kids', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/11.jpg'),
(37, 'nike37', '272.0', '461.0', '204.0', 'sports', 'large', 'red,black', 'mens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/12.jpg'),
(38, 'nike38', '442.0', '469.0', '221.0', 'sports', 'medium', 'green,silver', 'womens', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'images/13.jpg'),
(39, '', '0.0', '0.0', '0.0', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sign`
--

CREATE TABLE IF NOT EXISTS `sign` (
`id` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `email` text NOT NULL,
  `gender` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign`
--

INSERT INTO `sign` (`id`, `firstname`, `lastname`, `email`, `gender`, `password`) VALUES
(5, 'sonu', 'malik', 'msonu719@gmail.com', 'male', 'sonu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sign`
--
ALTER TABLE `sign`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `sign`
--
ALTER TABLE `sign`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
