<?php
session_start();
	require ('db.php');
	print_r($_POST);
	extract($_POST);
	$sql="select * from sign where email='$email' and password='$password'";
	$result=mysqli_query($con,$sql);
	if($result->num_rows>0)
	{
		$_SESSION['username']=$username;	
        header("location:welcome.php");
	}
	else
		echo "Account's invalid";


?>
