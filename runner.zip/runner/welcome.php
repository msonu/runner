<?php
session_start();
echo 'welcome' .$_SESSION['email'];
echo '<br><a href="index.php?action=logout">logout</a>'; 
?>