
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</php>>
<php>
<head>
<title>Runners sport  A Ecommerce Category Flat a Bootstarp  Website Template | Home :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<link href="css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/megamenu.js"></script>
<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
<script src="js/menu_jquery.js"></script>
<link rel="stylesheet" href="css/etalage.css">
<script src="js/jquery.easydropdown.js"></script>
<script src="js/jquery.etalage.min.js"></script>
<script>
			jQuery(document).ready(function($){

				$('#etalage').etalage({
					thumb_image_width: 300,
					thumb_image_height: 400,
					source_image_width: 900,
					source_image_height: 1200,
					show_hint: true,
					click_callback: function(image_anchor, instance_id){
						alert('Callback example:\nYou clicked on an image with the anchor: "'+image_anchor+'"\n(in Etalage instance: "'+instance_id+'")');
					}
				});

			});
		</script>

<script type="text/javascript" src="js/jquery.jscrollpane.min.js"></script>
		<script type="text/javascript" id="sourcecode">
			$(function()
			{
				$('.scroll-pane').jScrollPane();
			});
		</script>


</head>
<body>
<!--header stars-->
<?php include("menu.php");?>
	<!-- header ends -->
	
	<div class="banner1">
		<div class="container">
		</div>
	</div>
  <div class="men">
   	<div class="container">
      <div class="col-md-9 single_top">
      	 <h1 class="page-heading product-listing">
			Brands
         </h1>
         <div class="product-count">Showing 1 - 4 of 4 items</div>
          <div class="brand_box">
	         <div class="left-side col-xs-12 col-sm-3">
				 <img src="images/2nd-day.jpg" alt=""/>
			 </div>
		     <div class="middle-side col-xs-12 col-sm-5">
		     	<h4><a href="#">Lorem Ipsum</a></h4>
		     	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim</p>
			 </div>
			 <div class="right-side col-xs-12 col-sm-4">
			 	<p><a href="#">1 Product</a></p>
			    <a class="products" href="#">View Products</a>   			
			 </div>
			 <div class="clearfix"> </div>
		  </div>
		  <div class="brand_box">
	         <div class="left-side col-xs-12 col-sm-3">
				 <img src="images/weekday1.jpg" alt=""/>
			 </div>
		     <div class="middle-side col-xs-12 col-sm-5">
		     	<h4><a href="#">Lorem Ipsum</a></h4>
		     	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim</p>
			 </div>
			 <div class="right-side col-xs-12 col-sm-4">
			 	<p><a href="#">1 Product</a></p>
			    <a class="products" href="#">View Products</a>      
			 </div>
			 <div class="clearfix"> </div>
		  </div>
		  <div class="brand_box">
	         <div class="left-side col-xs-12 col-sm-3">
				 <img src="images/g-star-raw.jpg" alt=""/>
			 </div>
		     <div class="middle-side col-xs-12 col-sm-5">
		     	<h4><a href="#">Lorem Ipsum</a></h4>
		     	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim</p>
			 </div>
			 <div class="right-side col-xs-12 col-sm-4">
			 	<p><a href="#">1 Product</a></p>
			    <a class="products" href="#">View Products</a>     
			 </div>
			 <div class="clearfix"> </div>
		  </div>
		  <div class="brand_box">
	         <div class="left-side col-xs-12 col-sm-3">
				 <img src="images/weekday1.jpg" alt=""/>
			 </div>
		     <div class="middle-side col-xs-12 col-sm-5">
		     	<h4><a href="#">Lorem Ipsum</a></h4>
		     	<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliq'///////////////////m jmikkkkkkkkkkm,klklklklklklkl;k,kiiiiiiiiiiiiii,kiuam erat volutpat. Ut wisi enim</p>
			 </div>
			 <div class="right-side col-xs-12 col-sm-4">
			 	<p><a href="#">1 Product</a></p>
			      <a class="products" href="#">View Products</a>     
			 </div>
			 <div class="clearfix"> </div>
		  </div>
		</div>
		<div class="col-md-3 brand-left">
	      <h3 class="m_1">Related Products</h3>
	      <ul class="product">
	      	<li class="product_img"><img src="images/10.jpg" class="img-responsive" alt=""/></li>
	      	<li class="product_desc">
	      		<h4><a href="#">quod mazim</a></h4>
	      		<p class="single_price">$66.30</p>
	      		<a href="#" class="link-cart">Add to Wishlist</a>
	      	    <a href="#" class="link-cart">Add to Cart</a>
	        </li>
	      	<div class="clearfix"> </div>
	      </ul>
	      <ul class="product">
	      	<li class="product_img"><img src="images/9.jpg" class="img-responsive" alt=""/></li>
	      	<li class="product_desc">
	      		<h4><a href="#">quod mazim</a></h4>
	      		<p class="single_price">$66.30</p>
	      		<a href="#" class="link-cart">Add to Wishlist</a>
	      	    <a href="#" class="link-cart">Add to Cart</a>
	        </li>
	      	<div class="clearfix"> </div>
	      </ul>
	      <ul class="product">
	      	<li class="product_img"><img src="images/8.jpg" class="img-responsive" alt=""/></li>
	      	<li class="product_desc">
	      		<h4><a href="#">quod mazim</a></h4>
	      		<p class="single_price">$66.30</p>
	      		<a href="#" class="link-cart">Add to Wishlist</a>
	      	    <a href="#" class="link-cart">Add to Cart</a>
	        </li>
	      	<div class="clearfix"> </div>
	      </ul>
	      <ul class="product">
	      	<li class="product_img"><img src="images/7.jpg" class="img-responsive" alt=""/></li>
	      	<li class="product_desc">
	      		<h4><a href="#">quod mazim</a></h4>
	      		<p class="single_price">$66.30</p>
	      		<a href="#" class="link-cart">Add to Wishlist</a>
	      	    <a href="#" class="link-cart">Add to Cart</a>
	        </li>
	      	<div class="clearfix"> </div>
	      </ul>
        </div>
     <div class="clearfix"> </div>
	</div>
    </div>
<!-- footer -->
	<?php include("footer.php");?>
<!-- footer close -->
</body>
</html>