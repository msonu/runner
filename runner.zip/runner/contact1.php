<?php 
include("db.php");
extract($_POST);
$sql="INSERT INTO sign (firstname, lastname, email, gender, password) VALUES ('$firstname', '$lastname', '$email', '$gender', '$password')";
$result=mysqli_query($con,$sql);
if ($result) 
{
	echo "success";
}
else
{
	echo "unsuccss";
}
?>