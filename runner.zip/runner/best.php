<div class="sellers">
							<h3 class="m_2">Best sellers</h3>
								<?php  
include("db.php");
$sql="select * from product where category like 'mens'limit 3";
$result1=mysqli_query($con,$sql);
 
  while($row1=mysqli_fetch_array($result1)): ?>
								<div class="best">
									<div class="icon">
										<img src="<?php echo $row1['sku']; ?>" alt=" " class="img-responsive" />
									</div>
									<div class="data">
										<h4><a href="#"><?php echo $row1['product_name']?></a></h4>
										<p><del><?php echo $row1['old_price']?></del></p>
										<h5><?php echo $row1['new_price']?></h5>
									</div>
									<div class="clearfix"></div>
								</div>
									<?php endwhile; ?>
						 </div> 
					 
						<div class="sellers">
					
							<h3 class="m_2">tags</h3>
							<?php  
include("db.php");
$sql="select tags from product group by tags";
$result1=mysqli_query($con,$sql);
 
  while($row1=mysqli_fetch_array($result1)): ?>
								<div class="tags">
									<ul>
										<li><a href="#"><?php echo $row1['tags']?></a></li>
									</ul>

								</div>
							<?php endwhile;  ?>
						</div>
				
		       <section  class="sky-form">
					<div class="sellers">
							<h3 class="m_2">Special Offers</h3>
							<section class="slider">
						<div class="flexslider">

							<ul class="slides">
							<?php  
include("db.php");
$sql="select * from product where category like 'mens' limit 2";
$result1=mysqli_query($con,$sql);
 
  while($row1=mysqli_fetch_array($result1)): ?>
								<li>
									<div class="tittle">
										<img src="<?php echo $row1['sku']; ?>" alt=" " class="img-responsive" />
										<h6><?php echo $row1['product_name']?></h6>
										<p><?php echo $row1['descriptiotn']?></p>
										<a class="show1" href="#">SHOW ME MORE</a>
									</div>
								</li>
							<?php endwhile;  ?>
								
							</ul>
						</div>
					</section>
				