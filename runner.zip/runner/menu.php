
	<div class="header" style="z-index:10000;">
	<div class="top_bg">
<div class="container">
<div class="header_top">
	<div class="logo">
				<a href="index.php"><img src="images/logo.png" alt=""/></a>
			</div>
	<div class="top_right">
		<ul>
			<li><a href="registration.php">Create Account </a></li>|
			<li><a href="contact.php">Contact</a></li>|
			<li class="login" >
						<div id="loginContainer"><a href="#" id="loginButton"><span>Login</span></a>
						    <div id="loginBox">                
						        <form id="loginForm">
						                <fieldset id="body">
						                	<fieldset>
						                          <label for="email">Email Address</label>
						                          <input type="text" name="email" id="email">
						                    </fieldset>
						                    <fieldset>
						                            <label for="password">Password</label>
						                            <input type="password" name="password" id="password">
						                     </fieldset>
						                    <input type="submit" id="login" value="Sign in">
						                	<label for="checkbox"><input type="checkbox" id="checkbox"> <i>Remember me</i></label>
						            	</fieldset>
						            <span><a href="#">Forgot your password?</a></span>
							 </form>
				        </div>
			      </div>
			</li>
		</ul>
	</div>
	<div class="clearfix"> </div>
</div>
</div>
</div>
	</div>
	<div class="head-bann">
		<div class="container">
			<div class="head-nav">
				<span class="menu"> </span>
					<ul class="megamenu skyblue">
			<li><a class="color1" href="index.php">Home</a></li>
			<li class="grid"><a class="color2" href="women.php">Men's</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>my company</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>popular</h4>
								<ul>
									<li><a href="women.php">men</a></li>
									<li><a href="women.php">women</a></li>
									<li><a href="women.php">kids</a></li>
									<li><a href="women.php">sports</a></li>
									<li><a href="women.php">brands</a></li>
									<li><a href="women.php">collections</a></li>
								</ul>	
							</div>
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>account</h4>
								<ul>
									<li><a href="women.php">login</a></li>
									<li><a href="women.php">create an account</a></li>
									<li><a href="women.php">create wishlist</a></li>
									<li><a href="women.php">my shopping bag</a></li>
									<li><a href="women.php">brands</a></li>
									<li><a href="women.php">create wishlist</a></li>
								</ul>	
							</div>						
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>shop</h4>
								<img src="images/7.jpg">
								<h3 class="text-primary">latest Shoes</h3>
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>help</h4>
								<ul>
								<li><img src="images/8.jpg"></li>
									<li>
										<form class="form-group">
											<label class="label label-primary">Search for products</label>
											<br/>
											<br/>
											<input type="text" placeholder="search items" class="form-control">
											<br/>
											<input class="btn btn-primary btn-block" value="search for products">
											<br/>
										</form>
									</li>
									
								</ul>	
							</div>							
						</div>
						
						
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>
			<li><a class="color4" href="#">Women's</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>Latest in Trends</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>help</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>my company</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>												
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>shop</h4>
								<img src="images/7.jpg">
								<h3 class="text-primary">latest Shoes</h3>
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>help</h4>
								<ul>
								<li><img src="images/8.jpg"></li>
									<li>
										<form class="form-group">
											<label class="label label-primary">Search for products</label>
											<br/>
											<br/>
											<input type="text" placeholder="search items" class="form-control">
											<br/>
											<input class="btn btn-primary btn-block" value="search for products">
											<br/>
										</form>
									</li>
									
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>popular</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>				
				<li><a class="color5" href="#">Kids</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>shop</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>help</h4>
								<ul>
									<li><img src="images/logo1.png"></li>
									<li><img src="images/shoe.jpg"></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>my company</h4>
								<ul>
									<li>
									<form class="form-group">
										<label class="label label-primary">Search for products</label>
										<br/>
										<br/>
										<input type="text" placeholder="search items" class="form-control">
										<br/>
										<input class="btn btn-primary btn-block" value="search for products">
										<br/>
									</form>
									</li>
								</ul>	
							</div>												
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>account</h4>
								<ul>
									<li><a href="women.php">login</a></li>
									<li><a href="women.php">create an account</a></li>
									<li><a href="women.php">create wishlist</a></li>
									<li><a href="women.php">my shopping bag</a></li>
									<li><a href="women.php">brands</a></li>
									<li><a href="women.php">create wishlist</a></li>
								</ul>	
							</div>						
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>my company</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>popular</h4>
								<ul>
									<li><a href="women.php">men</a></li>
									<li><a href="women.php">women</a></li>
									<li><a href="women.php">kids</a></li>
									<li><a href="women.php">sports</a></li>
									<li><a href="women.php">brands</a></li>
									<li><a href="women.php">collections</a></li>
								</ul>	
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>
				<li><a class="color6" href="#">Sports</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>shop</h4>
								<ul>
									<li><a href="women.php">men</a></li>
									<li><a href="women.php">women</a></li>
									<li><a href="women.php">kids</a></li>
									<li><a href="women.php">sports</a></li>
									<li><a href="women.php">brands</a></li>
									<li><a href="women.php">collections</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>help</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>my company</h4>
								<ul>
									<li><a href="women.php?category=men">men</a></li>
									<li><a href="women.php?category=women">women</a></li>
									<li><a href="women.php?category=kids">kids</a></li>
									<li><a href="women.php?category=sports">sports</a></li>
									<li><a href="women.php?category=brands">brands</a></li>
									<li><a href="women.php?category=collections">collections</a></li>
								</ul>	
							</div>												
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>account</h4>
								<ul>
									<li><a href="women.php">login</a></li>
									<li><a href="women.php">create an account</a></li>
									<li><a href="women.php">create wishlist</a></li>
									<li><a href="women.php">my shopping bag</a></li>
									<li><a href="women.php">brands</a></li>
									<li><a href="women.php">create wishlist</a></li>
								</ul>	
							</div>						
						</div>
						<div class="col2">
							<div class="h_nav">
								<h4>my company</h4>
								<img src="images/10.jpg">	
							</div>
						</div>
						

					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>
					<li><a class="color7" href="brands.php">Brands</a>
				</li>
				<li><a class="color8" href="#">Collections</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>sports wear</h4>
								<ul>
									<li><img src="images/1.jpg"></li>
									<li><img src="images/2.jpg"></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>casual wear</h4>
								<ul>
									<li><img src="images/11.jpg"></li>
									<li><img src="images/12.jpg"></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>popular ones</h4>
								<ul>
									<li><img src="images/8.jpg"></li>
									<li><img src="images/9.jpg"></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>featured</h4>
								<ul>
									<li><img src="images/3.jpg"></li>
									<li><img src="images/5.jpg"></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>SALE (40% )</h4>
								<ul>
									<li><img src="images/1.jpg"></li>
									<li><img src="images/2.jpg"></li>
								</ul>	
							</div>							
						</div>

						
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    			   </div>
				</li>
				<div class="clearfix"> </div>
		 </ul> 
			</div>
		</div>	
	</div>
					<!-- script-for-nav -->
					<script>
						$( "span.menu" ).click(function() {
						  $( ".head-nav ul" ).slideToggle(300, function() {
							// Animation complete.
						  });
						});
					</script>
