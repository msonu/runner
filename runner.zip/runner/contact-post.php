<?php
include("db.php");
$username=$_POST['username'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$subject=$_POST['subject'];
$sql1="insert into contact(username,email,mobile,subject) values('$username','$email','$mobile','$subject')";
$result1=mysqli_query($con,$sql1);
if ($result1)
 {
 	echo "sucess";
 	header("location:index.php");
 } 
else
{
	echo "unsucess";
}

?>