<?php 
include("db.php");
ini_set("default_socket_timeout",600);
$a=extract($_POST);
$con=mysqli_connect("localhost","root","","runner");
$image=$_FILES['image']['tmp_name'];
$image=addslashes($image);
$image=file_get_contents($image);
$image=base64_encode($image);

// $sql="INSERT INTO product VALUES($category', '$tags', '$title', '$description', '$old_price', '$new_price', '$rating', '$colors', '$image')";

$sql="INSERT INTO product(product_name, product_price, old_price, new_price, tags, size, colors, category, descriptiotn, sku) VALUES ('$product_name', '$old_price', '$old_price', '$new_price', '$tags', '$size', '$colors', '$category', '$description','$image')";

$result=mysqli_query($con,$sql);
if($result)
{
	echo "success";
}
else
{
	echo "fail";
	echo mysqli_error($con);
}


 ?>