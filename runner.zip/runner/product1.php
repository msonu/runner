<!DOCTYPE html>
<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<link href="css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/form.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/megamenu.js"></script>
<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
<script src="js/menu_jquery.js"></script>
<script src="js/jquery.easydropdown.js"></script>
<script src="js/jquery.etalage.min.js"></script>
<script>
			jQuery(document).ready(function($){

				$('#etalage').etalage({
					thumb_image_width: 300,
					thumb_image_height: 400,
					source_image_width: 800,
					source_image_height: 1000,
					show_hint: true,
					click_callback: function(image_anchor, instance_id){
						alert('Callback example:\nYou clicked on an image with the anchor: "'+image_anchor+'"\n(in Etalage instance: "'+instance_id+'")');
					}
				});

			});
		</script>
<style type="text/css">
	form.form-group div
	{
		margin-top:10px;
	}
</style>
	<title></title>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-md-6">
			<h1>add product</h1>
		<form action="upload.php" method="post" enctype="multipart/form-data" class="form-group">
		<div class="col-md-6">
			<div>
			<label>Category</label>
			<input type="text" name="category" class="form-control" placeholder="category" value="">
			</div>
			<div>
			<label>tags</label>
			<input type="text" name="tags" class="form-control" placeholder="tags" value="">
			</div>
			<div>
			<label>Size</label>
			<select name="size" class="form-control">
				<option disabled >select a size</option>
				<option>7</option>
				<option selected>8</option>
				<option>9</option>
				<option>10</option>
			</select>
			</div>

			<div>
			<label>title</label>
			<input type="text" name="title" class="form-control" placeholder="title">
			</div>

			<div>
			<label>description</label>
			<input type="text" name="description" class="form-control" placeholder="description" value="">
			</div>


		</div>
		<div class="col-md-4">
			
				<div>
				<label>old_price</label>
				<input type="number" name="old_price" class="form-control" placeholder="old_price" value="">
				</div>

				<div>
				<label>new_price</label>
				<input type="number" name="new_price" class="form-control" placeholder="new_price" value="">
				</div>
				<div>
				<label>colors</label>
				<input type="text" name="colors" class="form-control" placeholder="colors" value="">
				</div>

				<div>
				<label>image</label>
				<input type="file" name="image" class="form-control" placeholder="image">
				</div>

				
		</div>					
		<div class="col-md-4">
		<input type="submit" name="submit" class="btn btn-block btn-success">
		<input type="reset" name="submit" class="btn btn-block btn-danger">
		</div>

			</form>
			
		</div>
	</div>
</div>
</body>
</html>
